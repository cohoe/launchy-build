For installation instructions, please refer to the INSTALL.txt file.  This file is for the author's random notes to himself.

2.2 Issues in OS X:
. need to be able to bring launchy up on any virtual desktop, not have to switch to launchy's desktop

2.2 Issues in Linux:



Bugs for 2.2:


To be done for 2.2 All:
. why are there so many checks for updates on some networks?  It seems like it should only happen once..
. add a history of recent commands mapped to up arrow
. fix text alignment problem for output box in skins (discussed in skins 2.0 forum)

To be done for 2.2 Windows:
. Rescue mode should kill running Launchy's
. .png and .ico files should display correctly.
. add a run as admin option

To be done for 2.1.3:
. Lost .png support in Windows.  It just shows the default png app as opposed to the actual picture.  This is due to my switch back in windows for 2.1.2 for .ico support.


Done for 2.1.2:
. Multiple tabs problem fixed.
. Added support for plugins to load other plugins (now python plugins can be made)
. Added back .ico support

2.0+:
. Add memory for runny/launchy (rebuild/exit/etc..)
. Add a plugin for open with etc..
. Add BBorn's kanji shortcuts


Done for 2.1:
. Added default search
. Better file browsing (/ and \ now tab complete)
. Added rescue mode (new shortcut in start menu)
. Fixed the database update timer
. Limited the transparency to a minimum of 15%
. Fixed the centering problem when multiple monitors in use
. Fixed the encoding problem with urls, e.g. googling for "c#" now works
. Searches are now even faster, and the catalog uses slightly less memory.


To be fixed from 2.0:
. encording of url characters in weby
. Memory problem


