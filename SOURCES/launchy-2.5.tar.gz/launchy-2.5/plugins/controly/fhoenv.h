// Copyright 2009 Fabian Hofsaess

#ifndef FHOENV_H
#define FHOENV_H


class FhoEnv {
	public:

		static QString expand(QString str);
};


#endif