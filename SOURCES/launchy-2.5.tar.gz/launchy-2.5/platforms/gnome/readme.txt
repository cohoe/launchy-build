Left off: Trying to prevent the alpha window from being selected.  Once it's selected it covers up the main window and I can't select its text box.
